# r14c v6.7 Targeted Reproduction — Frozen Artifacts

Frozen on: 2026-05-09
Branch: r14c/v67-targeted-reproduction (from claude/serene-archimedes-7cf7ca @ c88772e)
Run id (primary): r14c-v67-targeted-20260509T093414
Run id (Opus rejudge): r14c-v67-targeted-20260509T093414.rejudge.opus47-20260509T101059

## Configuration

- Answer provider: anthropic / claude-sonnet-4-6, T=0
- Primary judge: openai / gpt-5.1, T=0
- Rejudge: anthropic / claude-opus-4-7, T=0
- Case dir: cases_holdout (20 cases)
- Trials: 3
- Eval conditions: baseline, production_blocker_first_v6.3_candidate, production_blocker_first_v6.7_candidate
- Primary condition: production_blocker_first_v6.7_candidate
- Pairwise comparisons: production_blocker_first_v6.7_candidate:production_blocker_first_v6.3_candidate
- Double-swapped pairwise: false

## Source-of-truth files

- GPT-5.1 absolute results: r14c-v67-targeted-20260509T093414.results.jsonl
- GPT-5.1 absolute summary: r14c-v67-targeted-20260509T093414.summary.json
- GPT-5.1 pairwise gold_anchored: r14c-v67-targeted-20260509T093414.pairwise.gold_anchored.jsonl
- GPT-5.1 pairwise gold_blind: r14c-v67-targeted-20260509T093414.pairwise.gold_blind.jsonl
- Opus 4.7 rejudge absolute results: r14c-v67-targeted-20260509T093414.rejudge.opus47-20260509T101059.results.jsonl
- Opus 4.7 rejudge absolute summary: r14c-v67-targeted-20260509T093414.rejudge.opus47-20260509T101059.summary.json
- Opus 4.7 rejudge pairwise gold_anchored: r14c-v67-targeted-20260509T093414.rejudge.opus47-20260509T101059.pairwise.gold_anchored.jsonl
- Opus 4.7 rejudge pairwise gold_blind: r14c-v67-targeted-20260509T093414.rejudge.opus47-20260509T101059.pairwise.gold_blind.jsonl

## Row counts

- absolute primary: 180 (= 20 cases × 3 trials × 3 conditions)
- absolute rejudge: 180
- pairwise primary (each mode): 60 (= 20 cases × 3 trials × 1 comparison)
- pairwise rejudge (each mode): 60
